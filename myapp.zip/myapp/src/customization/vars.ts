export const $nodewidth = 200;
export const $socketmargin = 6;
export const $socketsize = 16;
