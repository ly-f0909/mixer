import { ClassicPreset as Classic } from 'rete';

export const socket = new Classic.Socket('socket');
