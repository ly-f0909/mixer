# 项目启动方法

1. 打开`terminal`终端
2. 转到对应路径
3. 输入`npm run build`
4. 等待创建完成后，输入`npm run dev`